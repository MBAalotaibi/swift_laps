//
//  ViewController.swift
//  researchPapers
//
//  Created by Mohammed Abdullah Alotaibi on 21/12/2022.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

